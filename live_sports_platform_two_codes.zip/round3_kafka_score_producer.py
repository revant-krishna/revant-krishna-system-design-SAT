import json
from kafka import KafkaProducer

producer = KafkaProducer(
    bootstrap_servers="localhost:9092",
    value_serializer=lambda data: json.dumps(data).encode("utf-8")
)

score_update = {
    "matchId": 101,
    "team": "India",
    "score": "185/4",
    "overs": 18.2
}

producer.send("live-scores", score_update)
producer.flush()
producer.close()

print("Live score update published")
