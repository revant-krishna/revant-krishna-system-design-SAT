LIVE SPORTS STREAMING & SCORE PLATFORM — CODE

Files:
1. round2_live_score_api.py
   Flask REST API example for retrieving a match's live score.

2. round3_kafka_score_producer.py
   Kafka producer example for publishing a live score update.

Dependencies:
- Round 2: pip install flask
- Round 3: pip install kafka-python

Run Round 2:
python round2_live_score_api.py

Then request:
http://127.0.0.1:5000/api/matches/101/score

Round 3 prerequisites:
- A Kafka broker must be running at localhost:9092.
- A topic named live-scores should exist (or topic auto-creation must be enabled).

Run Round 3:
python round3_kafka_score_producer.py

These are educational examples, not production-ready services.
