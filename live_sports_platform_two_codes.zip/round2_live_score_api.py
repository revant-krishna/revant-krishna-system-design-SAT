from flask import Flask, jsonify

app = Flask(__name__)

@app.route("/api/matches/<int:match_id>/score", methods=["GET"])
def get_live_score(match_id):
    if match_id != 101:
        return jsonify({"error": "Match not found"}), 404

    return jsonify({
        "matchId": 101,
        "team1": "India",
        "team2": "Australia",
        "score": "India 185/4",
        "overs": 18.2,
        "status": "LIVE"
    }), 200

if __name__ == "__main__":
    app.run(debug=True)
